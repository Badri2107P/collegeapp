package in.care.ac.caregroupofinstitutions;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;

import static android.content.ContentValues.TAG;


public class ProfileFragment extends Fragment {

TextView name,branch;
    public ProfileFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        //Log.e("run","1");




        FragmentManager childFragMan = getChildFragmentManager();
        FragmentTransaction childFragTrans = childFragMan.beginTransaction();
        ProfileContainerFragment fragB = new ProfileContainerFragment ();
        childFragTrans.add(R.id.profile_fragment_container, fragB);
        childFragTrans.addToBackStack("B");
        childFragTrans.commit();

        View view= inflater.inflate(R.layout.fragment_profile, container, false);

        name=(TextView)view.findViewById(R.id.nameprofile);
        branch=(TextView)view.findViewById(R.id.branchprofile);
        SessionManager session=new SessionManager(getActivity().getApplicationContext());
        HashMap<String,String> details=session.GetDetails();
        name.setText(details.get("name"));
        String ss=GetYear(details.get("year"));
        branch.setText(details.get("branch")+", "+ss);
        return view;
    }
    public String GetYear(String s){
        //   Log.i("Year",s);
        String t="";
        if(s.equals("1")){
            t="First Year";
        }
        if(s.equals("2")){
            t="Second Year";
        }
        if(s.equals("3")){
            t="Third Year";
        }
        if(s.equals("4")){
            t="Fourth Year";
        }if(s.equals("5")){
            t="Fifth Year";
        }if(s.equals("6")){
            t="Sixth Year";
        }if(s.equals("7")){
            t="Seventh Year";
        }
        return t;
    }
}
