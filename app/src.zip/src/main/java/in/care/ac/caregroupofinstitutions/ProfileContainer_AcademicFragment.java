package in.care.ac.caregroupofinstitutions;

import android.app.Activity;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import static android.R.attr.fragment;
import static android.content.ContentValues.TAG;
import static in.care.ac.caregroupofinstitutions.R.id.parent;
import static in.care.ac.caregroupofinstitutions.R.id.profile_fragment_container;


public class ProfileContainer_AcademicFragment extends Fragment {


    RelativeLayout attend,exam,sched;

    public ProfileContainer_AcademicFragment() {
        // Required empty public constructor
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_profile_container__academic, container, false);

        Log.e("run","3");
        attend=(RelativeLayout)view.findViewById(R.id.attendanceprofile);
        exam=(RelativeLayout)view.findViewById(R.id.examprofile);
        sched=(RelativeLayout)view.findViewById(R.id.scheduleprofile);

    return view;
    }



    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

final ProfileContainerFragment profile =new ProfileContainerFragment();
        attend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
            launchFragment(new AttendanceFragment());

            }
        });

        exam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
             launchFragment(new MarksFragment());
            }
        });
    }

    private void launchFragment(Fragment fragment) {
        FragmentManager manager = getActivity().getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        transaction.replace(R.id.fragment_container, fragment);
        transaction.commit();
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

}
