package in.care.ac.caregroupofinstitutions;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link HomeFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link HomeFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class HomeFragment extends Fragment {

    private ProgressDialog pDialog;
    private String TAG = MainActivity.class.getSimpleName();

    private ListView lv;

    private SessionManager session;

TextView name,branch;

    // URL to get contacts JSON
    private static String url = "http://192.168.0.104/clg/attendance.php?rollno=b15cs003 & date=2017-01-04 ";

    ArrayList<HashMap<String, String>> AttendList;

private TextView attnd;
    private LinearLayout exam;

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    public HomeFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment HomeFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        session=new SessionManager(getActivity().getApplicationContext());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_home, container, false);
        final MainActivity main= (MainActivity) getActivity();
        AttendList = new ArrayList<>();
        attnd=(TextView) view.findViewById(R.id.attndmenu);
        name=(TextView) view.findViewById(R.id.namehome);
        branch=(TextView) view.findViewById(R.id.branchhome);
        exam=(LinearLayout) view.findViewById(R.id.markshome);
      //  Log.i("Hashmap",session.GetDetails().toString());
        HashMap<String,String> details=session.GetDetails();
        //new GetAttendance().execute();
        name.setText(details.get("name"));
        String ss=GetYear(details.get("year"));
        branch.setText(details.get("branch")+", "+ss);
      //  Log.i("Year",GetYear(details.get("year")));
        attnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               main.loadFragment(new AttendanceFragment());
            }
        });

        exam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                main.loadFragment(new MarksFragment());
            }
        });

        return view;

    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            Toast.makeText(context, "Home", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    private class GetAttendance extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress dialog

            pDialog = new ProgressDialog(getActivity());
            pDialog.setMessage("Gathering Data..");
            pDialog.setIndeterminate(false);
            pDialog.setCancelable(true);
            pDialog.show();

        }

        @Override
        protected Void doInBackground(Void... arg0) {
            HTTPHandler sh = new HTTPHandler();

            // Making a request to url and getting response
            String jsonStr = sh.makeServiceCall(url);

            Log.e(TAG, "Response from url: " + jsonStr);

            if (jsonStr != null) {
                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);

                    // Getting JSON Array node
                    JSONArray attnd = jsonObj.getJSONArray("attendance");

                    // looping through All Contacts
                    for (int i = 0; i < attnd.length(); i++) {

                        JSONObject c = attnd.getJSONObject(i);

                        String atndFlag = c.getString("atnd_flag");
                        String attndHour = c.getString("atnd_hour");

                        // tmp hash map for single contact
                        HashMap<String, String> attnds = new HashMap<>();
                        int a = Integer.parseInt(atndFlag);
                    //    Log.i("hash1",atndFlag);
                        if(a==1){
                            attnds.put("attndFlag", "P");
                        }else {
                            attnds.put("attndFlag", "A");
                        }
                        // adding each child node to HashMap key => value

                        attnds.put("attndHour",attndHour);

                        // adding contact to contact list
                        AttendList.add(attnds);

                    }
                } catch (final JSONException e) {
                    Log.e(TAG, "Json parsing error: " + e.getMessage());


                }
            } else {
                Log.e(TAG, "Couldn't get json from server.");


            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            Parsedata();
            pDialog.dismiss();
        }



    }

    public void Parsedata(){

        for (int i=1; i<= AttendList.size();i++){
            String n="homeattnd"+i;
        //    Log.i("Hash",AttendList.get(i-1).get("attndFlag"));
            changeText(this.getActivity(),n,AttendList.get(i-1).get("attndFlag"));
        }

    }
    public void changeText(Activity a, String textViewId, String text) {
        String packageName = getActivity().getPackageName();
        int resId = getResources().getIdentifier(textViewId, "id", packageName);
      //  Log.i("hash1",Integer.toString(resId));

        TextView tv = (TextView) a.findViewById(resId);
        tv.setText(text);
    }

    public String GetYear(String s){
     //   Log.i("Year",s);
        String t="";
        if(s.equals("1")){
            t="First Year";
        }
        if(s.equals("2")){
            t="Second Year";
        }
        if(s.equals("3")){
            t="Third Year";
        }
        if(s.equals("4")){
            t="Fourth Year";
        }if(s.equals("5")){
            t="Fifth Year";
        }if(s.equals("6")){
            t="Sixth Year";
        }if(s.equals("7")){
            t="Seventh Year";
        }
        return t;
    }

}
